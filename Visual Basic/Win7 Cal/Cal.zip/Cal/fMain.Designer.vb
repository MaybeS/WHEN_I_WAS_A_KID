﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fMain
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.AText = New System.Windows.Forms.TextBox()
        Me.Btext = New System.Windows.Forms.TextBox()
        Me.Asc = New System.Windows.Forms.Label()
        Me.Num7 = New System.Windows.Forms.Button()
        Me.Num8 = New System.Windows.Forms.Button()
        Me.Num9 = New System.Windows.Forms.Button()
        Me.Num6 = New System.Windows.Forms.Button()
        Me.Num5 = New System.Windows.Forms.Button()
        Me.Num4 = New System.Windows.Forms.Button()
        Me.Num3 = New System.Windows.Forms.Button()
        Me.Num2 = New System.Windows.Forms.Button()
        Me.Num1 = New System.Windows.Forms.Button()
        Me.NumDot = New System.Windows.Forms.Button()
        Me.Num0 = New System.Windows.Forms.Button()
        Me.B_Ms = New System.Windows.Forms.Button()
        Me.B_Mr = New System.Windows.Forms.Button()
        Me.B_Mc = New System.Windows.Forms.Button()
        Me.B_Mp = New System.Windows.Forms.Button()
        Me.B_Mm = New System.Windows.Forms.Button()
        Me.B_C = New System.Windows.Forms.Button()
        Me.B_CE = New System.Windows.Forms.Button()
        Me.BackSp = New System.Windows.Forms.Button()
        Me.C_pm = New System.Windows.Forms.Button()
        Me.C_r = New System.Windows.Forms.Button()
        Me.C_per = New System.Windows.Forms.Button()
        Me.C_s = New System.Windows.Forms.Button()
        Me.C_sX = New System.Windows.Forms.Button()
        Me.C_x = New System.Windows.Forms.Button()
        Me.C_m = New System.Windows.Forms.Button()
        Me.C_e = New System.Windows.Forms.Button()
        Me.C_p = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MemoR = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'AText
        '
        Me.AText.BackColor = System.Drawing.Color.White
        Me.AText.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.AText.Font = New System.Drawing.Font("나눔고딕", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.AText.Location = New System.Drawing.Point(6, 12)
        Me.AText.Name = "AText"
        Me.AText.Size = New System.Drawing.Size(252, 15)
        Me.AText.TabIndex = 1
        Me.AText.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Btext
        '
        Me.Btext.BackColor = System.Drawing.Color.White
        Me.Btext.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Btext.Font = New System.Drawing.Font("나눔고딕", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Btext.Location = New System.Drawing.Point(29, 39)
        Me.Btext.Name = "Btext"
        Me.Btext.Size = New System.Drawing.Size(257, 19)
        Me.Btext.TabIndex = 2
        Me.Btext.Text = "0"
        Me.Btext.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Asc
        '
        Me.Asc.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Asc.Location = New System.Drawing.Point(264, 9)
        Me.Asc.Name = "Asc"
        Me.Asc.Size = New System.Drawing.Size(22, 27)
        Me.Asc.TabIndex = 3
        Me.Asc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Num7
        '
        Me.Num7.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num7.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num7.Location = New System.Drawing.Point(12, 150)
        Me.Num7.Name = "Num7"
        Me.Num7.Size = New System.Drawing.Size(51, 33)
        Me.Num7.TabIndex = 4
        Me.Num7.Text = "7"
        Me.Num7.UseVisualStyleBackColor = False
        '
        'Num8
        '
        Me.Num8.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num8.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num8.Location = New System.Drawing.Point(69, 150)
        Me.Num8.Name = "Num8"
        Me.Num8.Size = New System.Drawing.Size(51, 33)
        Me.Num8.TabIndex = 5
        Me.Num8.Text = "8"
        Me.Num8.UseVisualStyleBackColor = False
        '
        'Num9
        '
        Me.Num9.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num9.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num9.Location = New System.Drawing.Point(126, 150)
        Me.Num9.Name = "Num9"
        Me.Num9.Size = New System.Drawing.Size(51, 33)
        Me.Num9.TabIndex = 6
        Me.Num9.Text = "9"
        Me.Num9.UseVisualStyleBackColor = False
        '
        'Num6
        '
        Me.Num6.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num6.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num6.Location = New System.Drawing.Point(126, 189)
        Me.Num6.Name = "Num6"
        Me.Num6.Size = New System.Drawing.Size(51, 33)
        Me.Num6.TabIndex = 9
        Me.Num6.Text = "6"
        Me.Num6.UseVisualStyleBackColor = False
        '
        'Num5
        '
        Me.Num5.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num5.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num5.Location = New System.Drawing.Point(69, 189)
        Me.Num5.Name = "Num5"
        Me.Num5.Size = New System.Drawing.Size(51, 33)
        Me.Num5.TabIndex = 8
        Me.Num5.Text = "5"
        Me.Num5.UseVisualStyleBackColor = False
        '
        'Num4
        '
        Me.Num4.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num4.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num4.Location = New System.Drawing.Point(12, 189)
        Me.Num4.Name = "Num4"
        Me.Num4.Size = New System.Drawing.Size(51, 33)
        Me.Num4.TabIndex = 7
        Me.Num4.Text = "4"
        Me.Num4.UseVisualStyleBackColor = False
        '
        'Num3
        '
        Me.Num3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num3.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num3.Location = New System.Drawing.Point(126, 228)
        Me.Num3.Name = "Num3"
        Me.Num3.Size = New System.Drawing.Size(51, 33)
        Me.Num3.TabIndex = 12
        Me.Num3.Text = "3"
        Me.Num3.UseVisualStyleBackColor = False
        '
        'Num2
        '
        Me.Num2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num2.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num2.Location = New System.Drawing.Point(69, 228)
        Me.Num2.Name = "Num2"
        Me.Num2.Size = New System.Drawing.Size(51, 33)
        Me.Num2.TabIndex = 11
        Me.Num2.Text = "2"
        Me.Num2.UseVisualStyleBackColor = False
        '
        'Num1
        '
        Me.Num1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num1.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num1.Location = New System.Drawing.Point(12, 228)
        Me.Num1.Name = "Num1"
        Me.Num1.Size = New System.Drawing.Size(51, 33)
        Me.Num1.TabIndex = 10
        Me.Num1.Text = "1"
        Me.Num1.UseVisualStyleBackColor = False
        '
        'NumDot
        '
        Me.NumDot.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.NumDot.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.NumDot.Location = New System.Drawing.Point(126, 267)
        Me.NumDot.Name = "NumDot"
        Me.NumDot.Size = New System.Drawing.Size(51, 33)
        Me.NumDot.TabIndex = 15
        Me.NumDot.Text = "."
        Me.NumDot.UseVisualStyleBackColor = False
        '
        'Num0
        '
        Me.Num0.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Num0.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Num0.Location = New System.Drawing.Point(12, 267)
        Me.Num0.Name = "Num0"
        Me.Num0.Size = New System.Drawing.Size(108, 33)
        Me.Num0.TabIndex = 13
        Me.Num0.Text = "0"
        Me.Num0.UseVisualStyleBackColor = False
        '
        'B_Ms
        '
        Me.B_Ms.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.B_Ms.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.B_Ms.Location = New System.Drawing.Point(126, 72)
        Me.B_Ms.Name = "B_Ms"
        Me.B_Ms.Size = New System.Drawing.Size(51, 33)
        Me.B_Ms.TabIndex = 18
        Me.B_Ms.Text = "MS"
        Me.B_Ms.UseVisualStyleBackColor = False
        '
        'B_Mr
        '
        Me.B_Mr.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.B_Mr.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.B_Mr.Location = New System.Drawing.Point(69, 72)
        Me.B_Mr.Name = "B_Mr"
        Me.B_Mr.Size = New System.Drawing.Size(51, 33)
        Me.B_Mr.TabIndex = 17
        Me.B_Mr.Text = "MR"
        Me.B_Mr.UseVisualStyleBackColor = False
        '
        'B_Mc
        '
        Me.B_Mc.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.B_Mc.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.B_Mc.Location = New System.Drawing.Point(12, 72)
        Me.B_Mc.Name = "B_Mc"
        Me.B_Mc.Size = New System.Drawing.Size(51, 33)
        Me.B_Mc.TabIndex = 16
        Me.B_Mc.Text = "MC"
        Me.B_Mc.UseVisualStyleBackColor = False
        '
        'B_Mp
        '
        Me.B_Mp.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.B_Mp.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.B_Mp.Location = New System.Drawing.Point(183, 72)
        Me.B_Mp.Name = "B_Mp"
        Me.B_Mp.Size = New System.Drawing.Size(51, 33)
        Me.B_Mp.TabIndex = 19
        Me.B_Mp.Text = "M+"
        Me.B_Mp.UseVisualStyleBackColor = False
        '
        'B_Mm
        '
        Me.B_Mm.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.B_Mm.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.B_Mm.Location = New System.Drawing.Point(240, 72)
        Me.B_Mm.Name = "B_Mm"
        Me.B_Mm.Size = New System.Drawing.Size(51, 33)
        Me.B_Mm.TabIndex = 20
        Me.B_Mm.Text = "M-"
        Me.B_Mm.UseVisualStyleBackColor = False
        '
        'B_C
        '
        Me.B_C.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.B_C.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.B_C.Location = New System.Drawing.Point(126, 111)
        Me.B_C.Name = "B_C"
        Me.B_C.Size = New System.Drawing.Size(51, 33)
        Me.B_C.TabIndex = 23
        Me.B_C.Text = "C"
        Me.B_C.UseVisualStyleBackColor = False
        '
        'B_CE
        '
        Me.B_CE.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.B_CE.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.B_CE.Location = New System.Drawing.Point(69, 111)
        Me.B_CE.Name = "B_CE"
        Me.B_CE.Size = New System.Drawing.Size(51, 33)
        Me.B_CE.TabIndex = 22
        Me.B_CE.Text = "CE"
        Me.B_CE.UseVisualStyleBackColor = False
        '
        'BackSp
        '
        Me.BackSp.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.BackSp.Font = New System.Drawing.Font("나눔고딕", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.BackSp.Location = New System.Drawing.Point(12, 111)
        Me.BackSp.Name = "BackSp"
        Me.BackSp.Size = New System.Drawing.Size(51, 33)
        Me.BackSp.TabIndex = 21
        Me.BackSp.Text = "←"
        Me.BackSp.UseVisualStyleBackColor = False
        '
        'C_pm
        '
        Me.C_pm.BackColor = System.Drawing.SystemColors.Control
        Me.C_pm.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.C_pm.Location = New System.Drawing.Point(183, 111)
        Me.C_pm.Name = "C_pm"
        Me.C_pm.Size = New System.Drawing.Size(51, 33)
        Me.C_pm.TabIndex = 24
        Me.C_pm.Text = "±"
        Me.C_pm.UseVisualStyleBackColor = False
        '
        'C_r
        '
        Me.C_r.BackColor = System.Drawing.SystemColors.Control
        Me.C_r.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.C_r.Location = New System.Drawing.Point(241, 111)
        Me.C_r.Name = "C_r"
        Me.C_r.Size = New System.Drawing.Size(51, 33)
        Me.C_r.TabIndex = 25
        Me.C_r.Text = "√"
        Me.C_r.UseVisualStyleBackColor = False
        '
        'C_per
        '
        Me.C_per.BackColor = System.Drawing.SystemColors.Control
        Me.C_per.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.C_per.Location = New System.Drawing.Point(240, 150)
        Me.C_per.Name = "C_per"
        Me.C_per.Size = New System.Drawing.Size(51, 33)
        Me.C_per.TabIndex = 27
        Me.C_per.Text = "%"
        Me.C_per.UseVisualStyleBackColor = False
        '
        'C_s
        '
        Me.C_s.BackColor = System.Drawing.SystemColors.Control
        Me.C_s.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.C_s.Location = New System.Drawing.Point(182, 150)
        Me.C_s.Name = "C_s"
        Me.C_s.Size = New System.Drawing.Size(51, 33)
        Me.C_s.TabIndex = 26
        Me.C_s.Text = "÷"
        Me.C_s.UseVisualStyleBackColor = False
        '
        'C_sX
        '
        Me.C_sX.BackColor = System.Drawing.SystemColors.Control
        Me.C_sX.Font = New System.Drawing.Font("Freehand591 BT", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C_sX.Location = New System.Drawing.Point(241, 189)
        Me.C_sX.Name = "C_sX"
        Me.C_sX.Size = New System.Drawing.Size(51, 33)
        Me.C_sX.TabIndex = 29
        Me.C_sX.Text = "1/x"
        Me.C_sX.UseVisualStyleBackColor = False
        '
        'C_x
        '
        Me.C_x.BackColor = System.Drawing.SystemColors.Control
        Me.C_x.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.C_x.Location = New System.Drawing.Point(183, 189)
        Me.C_x.Name = "C_x"
        Me.C_x.Size = New System.Drawing.Size(51, 33)
        Me.C_x.TabIndex = 28
        Me.C_x.Text = "×"
        Me.C_x.UseVisualStyleBackColor = False
        '
        'C_m
        '
        Me.C_m.BackColor = System.Drawing.SystemColors.Control
        Me.C_m.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.C_m.Location = New System.Drawing.Point(183, 228)
        Me.C_m.Name = "C_m"
        Me.C_m.Size = New System.Drawing.Size(51, 33)
        Me.C_m.TabIndex = 30
        Me.C_m.Text = "-"
        Me.C_m.UseVisualStyleBackColor = False
        '
        'C_e
        '
        Me.C_e.BackColor = System.Drawing.SystemColors.Control
        Me.C_e.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.C_e.Location = New System.Drawing.Point(240, 228)
        Me.C_e.Name = "C_e"
        Me.C_e.Size = New System.Drawing.Size(51, 72)
        Me.C_e.TabIndex = 33
        Me.C_e.Text = "="
        Me.C_e.UseVisualStyleBackColor = False
        '
        'C_p
        '
        Me.C_p.BackColor = System.Drawing.SystemColors.Control
        Me.C_p.Font = New System.Drawing.Font("나눔고딕", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.C_p.Location = New System.Drawing.Point(182, 267)
        Me.C_p.Name = "C_p"
        Me.C_p.Size = New System.Drawing.Size(51, 33)
        Me.C_p.TabIndex = 32
        Me.C_p.Text = "+"
        Me.C_p.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.MemoR)
        Me.GroupBox1.Controls.Add(Me.Asc)
        Me.GroupBox1.Controls.Add(Me.Btext)
        Me.GroupBox1.Controls.Add(Me.AText)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(290, 66)
        Me.GroupBox1.TabIndex = 34
        Me.GroupBox1.TabStop = False
        '
        'MemoR
        '
        Me.MemoR.AutoSize = True
        Me.MemoR.Font = New System.Drawing.Font("나눔고딕", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.MemoR.Location = New System.Drawing.Point(7, 41)
        Me.MemoR.Name = "MemoR"
        Me.MemoR.Size = New System.Drawing.Size(25, 19)
        Me.MemoR.TabIndex = 4
        Me.MemoR.Text = "M"
        Me.MemoR.Visible = False
        '
        'fMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(304, 307)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.C_e)
        Me.Controls.Add(Me.C_p)
        Me.Controls.Add(Me.C_m)
        Me.Controls.Add(Me.C_sX)
        Me.Controls.Add(Me.C_x)
        Me.Controls.Add(Me.C_per)
        Me.Controls.Add(Me.C_s)
        Me.Controls.Add(Me.C_r)
        Me.Controls.Add(Me.C_pm)
        Me.Controls.Add(Me.B_C)
        Me.Controls.Add(Me.B_CE)
        Me.Controls.Add(Me.BackSp)
        Me.Controls.Add(Me.B_Mm)
        Me.Controls.Add(Me.B_Mp)
        Me.Controls.Add(Me.B_Ms)
        Me.Controls.Add(Me.B_Mr)
        Me.Controls.Add(Me.B_Mc)
        Me.Controls.Add(Me.NumDot)
        Me.Controls.Add(Me.Num0)
        Me.Controls.Add(Me.Num3)
        Me.Controls.Add(Me.Num2)
        Me.Controls.Add(Me.Num1)
        Me.Controls.Add(Me.Num6)
        Me.Controls.Add(Me.Num5)
        Me.Controls.Add(Me.Num4)
        Me.Controls.Add(Me.Num9)
        Me.Controls.Add(Me.Num8)
        Me.Controls.Add(Me.Num7)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "fMain"
        Me.Text = "계산기"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents AText As System.Windows.Forms.TextBox
    Friend WithEvents Btext As System.Windows.Forms.TextBox
    Friend WithEvents Asc As System.Windows.Forms.Label
    Friend WithEvents Num7 As System.Windows.Forms.Button
    Friend WithEvents Num8 As System.Windows.Forms.Button
    Friend WithEvents Num9 As System.Windows.Forms.Button
    Friend WithEvents Num6 As System.Windows.Forms.Button
    Friend WithEvents Num5 As System.Windows.Forms.Button
    Friend WithEvents Num4 As System.Windows.Forms.Button
    Friend WithEvents Num3 As System.Windows.Forms.Button
    Friend WithEvents Num2 As System.Windows.Forms.Button
    Friend WithEvents Num1 As System.Windows.Forms.Button
    Friend WithEvents NumDot As System.Windows.Forms.Button
    Friend WithEvents Num0 As System.Windows.Forms.Button
    Friend WithEvents B_Ms As System.Windows.Forms.Button
    Friend WithEvents B_Mr As System.Windows.Forms.Button
    Friend WithEvents B_Mc As System.Windows.Forms.Button
    Friend WithEvents B_Mp As System.Windows.Forms.Button
    Friend WithEvents B_Mm As System.Windows.Forms.Button
    Friend WithEvents B_C As System.Windows.Forms.Button
    Friend WithEvents B_CE As System.Windows.Forms.Button
    Friend WithEvents BackSp As System.Windows.Forms.Button
    Friend WithEvents C_pm As System.Windows.Forms.Button
    Friend WithEvents C_r As System.Windows.Forms.Button
    Friend WithEvents C_per As System.Windows.Forms.Button
    Friend WithEvents C_s As System.Windows.Forms.Button
    Friend WithEvents C_sX As System.Windows.Forms.Button
    Friend WithEvents C_x As System.Windows.Forms.Button
    Friend WithEvents C_m As System.Windows.Forms.Button
    Friend WithEvents C_e As System.Windows.Forms.Button
    Friend WithEvents C_p As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents MemoR As System.Windows.Forms.Label

End Class
